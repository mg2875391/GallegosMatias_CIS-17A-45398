/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: MatiasGallegos
 *
 * Created on June 25, 2021, 9:39 PM
 */

#include <cstdlib>
#include <iostream>
using namespace std;

int main(int argc, char** argv) {
    float Fahrenheit, Celsius;
    
    cout << "Enter the temperature in Celsius";
    cin >> Celsius;
    Fahrenheit = (Celsius * 9.0) / 5.0 + 32;
    cout << "Temperature in Celsius" << Celsius << endl;
    cout <<"Temperature in Fahrenheit" << Fahrenheit << endl;
    return 0;
}