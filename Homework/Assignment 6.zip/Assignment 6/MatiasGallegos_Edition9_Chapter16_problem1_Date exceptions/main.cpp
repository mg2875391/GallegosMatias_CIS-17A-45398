/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: matij
 *
*/

#include <cstdlib>
#include <iostream>
#include <string>

using namespace std;

const int NUM_MONTHS = 12;

class Date
{
int month; // to hold the month
   int day; // to hold the day
   int year; // to hold the year
   string names[NUM_MONTHS];
void setNames();
public:
// Constructor
    Date();
    Date(int , int , int );
    void setMonth(int m);
    void setDay(int);
    void setYear(int);
   // Function to print the date
   void showDate1();
   void showDate2();
   void showDate3();

   // Exception classes
   class InvalidDay {
   private:
       string msg; // containing the exception message
   public:
       InvalidDay() : msg("")
       {}
       
       InvalidDay(string msg): msg(msg)
       {}
       string what()
       {
           return msg;
       }
   };
   class InvalidMonth {
   private:
       string msg;
       
   public:
       InvalidMonth() : msg("")
       {}
       
       InvalidMonth(string msg): msg(msg)
       {}
       string what()
       {
           return msg;
       }
   };
};
Date::Date()
{
    day = 1;
    month = 1;
    year = 2021;
    setNames();
}

// Parameters: m is the month
// d is the day
// y is the year
Date::Date(int m, int d, int y)
{
    setMonth(m);
    setDay(d);
    setYear(y);
    setNames();
}
// This function assigns the names
// of the months to the names array
void Date::setNames()
{
    names[0] = "January";
    names[1] = "February";
    names[2] = "March";
    names[3] = "April";
    names[4] = "May";
    names[5] = "June";
    names[6] = "July";
    names[7] = "August";
    names[8] = "September";
    names[9] = "October";
    names[10] = "November";
    names[11] = "December";
}
// set the month to m
void Date::setMonth(int m)
{
    // between [1,12]
    if(m >= 1 && m <= 12)
        month = m;
    else
{
        // m < 1 || m > 12
        throw InvalidMonth("Invalid month "+to_string(m)+": Month must be between [1,12]");
    }
}
// set the day to d
void Date::setDay(int d)
{
    // validate d is between [1,31]
    if(d >= 1 && d <= 31)
        day = d;
    else
{
        // d < 1 || d > 31,
        throw InvalidDay("Invalid day "+to_string(d)+": Day must be between [1,31]");
    }
}
// set the year to y
void Date::setYear(int y)
{
    year = y;
}

// Displays the date in the form MM/DD/YY
void Date:: showDate1()
{
   std::cout << month << "/" << day << "/" << year << std::endl;
}

void Date:: showDate2()
{
   std::cout << names[month - 1]<< " " << day << ", " << year << std::endl;
}
void Date:: showDate3()
{
   std::cout << day << " " << names[month - 1] << " " << year << std::endl;
}

int main(int argc, char** argv) {
   // using the overloaded constructor.
   Date today(12, 31, 2021);

   // Show the date in form #1.
   today.showDate1();

   // loop to test the setMonth and setDay functions with valid and invalid values
   for(int month=10;month <=13; month++)
{
       for(int day=28; day <=32;day++)
       {
           try
           {
               // store a new month
               today.setMonth(month);

               // store a new day
               today.setDay(day);

               today.showDate1();
           }catch(Date::InvalidDay &e)
           {
               cout<<e.what()<<endl;
           }catch(Date::InvalidMonth &e)
           {
               cout<<e.what()<<endl;
           }
       }
   }                                                                                    
   return 0;
}