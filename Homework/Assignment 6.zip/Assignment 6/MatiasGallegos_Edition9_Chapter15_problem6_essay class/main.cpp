/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: matij
 *
 */

#include <cstdlib>
#include <iostream>

using namespace std;

// GradedActivity class declaration

class GradedActivity
{
    protected:
        double score; // To hold the numeric score
        public:
            // Default constructor
            GradedActivity()
            { score = 0.0; }
// Constructor

           GradedActivity(double s)
           { score = s; }
void setScore(double s)
{ 
    score = s;
}
//functions
virtual double getScore() const
{
    return score; }

virtual char getLetterGrade() const;
};

char GradedActivity::getLetterGrade() const
{
    char letterGrade; 
    // the value of the score 
    if (score > 90)
        letterGrade = 'A';
    else if (score > 80)
        letterGrade = 'B';
    else if (score > 70)
        letterGrade = 'C';
    else if (score > 60)
        letterGrade = 'D';
    else
        letterGrade = 'F';
    
return letterGrade;
}

int main(int argc, char** argv) {
    
    double grammer, spelling , length, content ;
    cout << "Enter the points of four subjects : ";
    cin >> grammer >> spelling >> length >> content ;

    double total = grammer + spelling + length + content ;
    cout << "\n Total Score is : "<< total;
    GradedActivity *g;
    GradedActivity d;
    g = &d;
    g-> setScore(total);
    g -> getScore();
    cout <<"\nYour Grade is:";
    cout << g -> getLetterGrade();
    return 0;
}