/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: matij
 *
 */

#include <cstdlib>
#include <iostream>
#include <string>

using namespace std;
//Employee class
class Employee
{
   private:
       string emp_name;
       int emp_no;
       string hire_date;
   public:
       //constructor
       Employee()
       {
           emp_name="";
           emp_no=0;
           hire_date="";
       }
       //parameterized constructor
       Employee(string name, int num, string date)
       {
              emp_name = name;
              emp_no = num;
              hire_date = date;
       }

       //declarations
       void set_name(string n);
       void set_empno(int n);
       void set_hiredate(string d);
       string get_name();
       int get_number();
       string get_date();     
};
// function to set name
void Employee::set_name(string n)
{
emp_name = n ;
}
//function to set employee number
void Employee::set_empno(int n)
{
   emp_no = n;
}
// function to set hire date
void Employee::set_hiredate(string d)
{
   hire_date = d;
}
// function to get name
string Employee::get_name()
{
   return emp_name;
}
//function to get number
int Employee::get_number()
{
   return emp_no;
}
// function to get hire date
string Employee::get_date()
{
   return hire_date;
}
// ProductionWorker class
class ProductionWorker : public Employee
{
   // private variables to store shift and hour pay
   private:
      int shift;
      double hour_pay;
   public:     
       // default constructor
       ProductionWorker()
       {
          shift =0;
          hour_pay=0;
       }
       // parameterized constructor
        ProductionWorker(int sh , double pay)
        {
           shift = sh;
           hour_pay = pay;
        }
       //functions
       void set_shift(int s);
       void set_pay(double p);
       int get_shift();
       double get_pay();
       void display();
};
//display the employee details
void ProductionWorker::display()
{
       cout << "\nEmployee Name: " << get_name() << endl;
       cout << "Employee Number: " << get_number() << endl;
       cout << "Hire Date: " << get_date() << endl;
       cout << "Shift: " << get_shift();

       if(shift == 1)      
          cout << " - Day Shift" << endl;
       else
          cout << " - Night Shift" << endl;

         cout << "Pay Rate: $" << get_pay()<< endl;
}
//function to set shift
void ProductionWorker::set_shift(int sh)
{
   sh = shift;
}
//function to set pay
void ProductionWorker::set_pay(double p)
{
   p = hour_pay;
}
// function to get shift
int ProductionWorker::get_shift()
{
   return shift;
}
// function to get pay
double ProductionWorker::get_pay()
{
   return hour_pay;
}
int main(int argc, char** argv)
{
   int Shift;
   double pay;
   // getting shift and pay
   cout << "Enter 1 for Day Shift or 2 for Night Shift: "<<endl;
   cout<< "Other than 1 or 2, default to Night Shift: ";
   cin >> Shift;
   cout << "Enter hourly pay: $";
   cin >> pay;
   // creating ProductionWorker object
   ProductionWorker emp(Shift, pay);
   emp.set_name("John smith");
   emp.set_empno(1002);
   emp.set_hiredate("7-26-2021");
   emp.display();
  
   return 0;
}