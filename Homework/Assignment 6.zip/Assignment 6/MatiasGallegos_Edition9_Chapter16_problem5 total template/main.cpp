/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: matij
 *
 */

#include <cstdlib>
#include <iostream>
using namespace std;
template <typename T>
T total(T numValues)
{
   T total = 0;
   T v = 0;
   for(int i = 1; i <= numValues; i++)
   {
  
       cout << "\nEnter value number " << i<<":";
       cin >> v;
       total=total+ v;      
      
       cout << endl;
      
   }
   cout<<"\nSum of the values entered: "<< total;
   return total;

}
int main(int argc, char** argv) {
int n;
cout << "\nTotal Number of values: " ;
   cin >> n;
total(n);
   cin.ignore();
   cin.get();
   return 0;
}