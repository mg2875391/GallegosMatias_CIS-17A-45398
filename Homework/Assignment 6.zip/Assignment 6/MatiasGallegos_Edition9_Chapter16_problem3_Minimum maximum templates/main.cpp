/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: matij
 *
 */

#include <cstdlib>
#include<iostream>
using namespace std;

/*To find maximum of x and y*/
template <typename T>
T max(int x, int y)
{
return x ^ ((x ^ y) & -(x < y));
}
  

int main(int argc, char** argv) {

int x = 23;
int y = 34;
cout << "Min value : " << min(x, y);
cout << "\nMax value : " << max(x, y)<<endl;
  
getchar();
}