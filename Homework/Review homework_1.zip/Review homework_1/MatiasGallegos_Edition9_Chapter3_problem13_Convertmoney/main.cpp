/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: MatiasGallegos
 *
 * Created on June 26, 2021, 12:50 AM
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>

using namespace std;

int main(int argc, char** argv) {
//The conversion Rates from the question on the book
const double YEN_PER_DOLLAR = 98.93;
const double EUROS_PER_DOLLAR = 0.74;
// the three currency's
double Dollars, Yen, Euros;
cout << "Enter Dollars amount";
cin >> Dollars;
//conversion from Dollar to Yen
Yen = Dollars * YEN_PER_DOLLAR;
//conversion from Dollar to Euro
Euros = Dollars * EUROS_PER_DOLLAR;
cout << "Conversion:";
cout << Dollars << " = " << Yen << endl;
cout << Dollars << " = " << Euros << endl;
    return 0;
}