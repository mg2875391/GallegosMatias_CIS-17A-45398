/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: MatiasGallegos
 *
 * Created on June 26, 2021, 11:21 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
     float starting_num_of_organisms,
          average_daily_population_increase,
          size_of_daily_population;

    int num_of_days_to_multiply;

    cout << "Enter the starting number of organisms: ";

    while (!(cin >> starting_num_of_organisms) || 
                    starting_num_of_organisms < 2)
    {
        //cout that tells the user what is and not right
        cout << "No sorry. Starting number must be 2 or greater." << endl;
        cout << "Enter the starting number of organisms: ";
        cin.clear();
        cin.ignore(123, '\n');
    }

    cout << "Enter average daily population increase (%): ";

    while (!(cin >> average_daily_population_increase) || 
                    average_daily_population_increase < 0)
    {
        //cout that tells the user what is and not right
        cout << "No sorry. Average daily population increase must be greater than 0. \n"
             << " Enter average\n"  
             << " daily population increase (%): ";
        cin.clear();
        cin.ignore(123, '\n');
    }

    average_daily_population_increase *= .01;

    cout << "Enter number of days they will multiply: ";

    while(!(cin >> num_of_days_to_multiply) || 
                   num_of_days_to_multiply < 1)
    {
         //cout that tells the user what is and not right
        cout << "No sorry. Number of days must NOT be less than 1. \n"
             << "Enter number of day they will\n"
             << "multiply: ";
        cin.clear();
        cin.ignore(123, '\n');
    }
     // the number of days that are to multiply
    for(int i = 0; i < num_of_days_to_multiply; i++)
    {
        // the equation to solve the question
        cout << "Population size for day " << (i + 1);
        cout << ": " << starting_num_of_organisms 
             << endl;
        //To know the staring number of organisms
        starting_num_of_organisms += 
            (starting_num_of_organisms * 
             average_daily_population_increase);
    }
    
    return 0;
}