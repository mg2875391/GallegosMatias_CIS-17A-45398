/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: matiasGallegos
 *
 * Created on June 24, 2021, 9:05 PM
 */

#include <cstdlib>
#include <iostream>
using namespace std;

int main(int argc, char** argv) {
 cout<<" Enter month 1-12";
    int month;
    // all the month
    cin >> month;
    if (month==1)
            cout<<"January 31 ";
    else if (month==2)
        cout<<"February";
    else if (month==3)
        cout<<"March 31 Days";
    else if (month==4)
        cout<<"April 30 Days";
    else if (month==5)
        cout<<"May 31 Days";
    else if (month==6)
        cout<<"June 31 Days";
    else if (month==7)
        cout<<"July 30 Days";
    else if (month==8)
        cout<<"August 31 Days";
    else if (month==9)
        cout<<"September 30 Days";
    else if (month==10)
        cout<<"October 31 Days";
    else if (month==11)
        cout<<"November 30 Days";
    else if (month==12)
        cout<<"December 31 Days";
    cout << endl;{
        int year;
        //to tell the user to enter the year
    cout << " Enter a year";
    cin >> year;
    // solution to determine a leap year 
    if (year % 4 == 0) {
    if (year % 100 == 0) {
    if (year % 400 == 0)
        //to tell the user what is and not a leap year
    cout << year << " is a leap year .";
    else
    cout << year << " is not a leap year.";
        }
    else
    cout << year << " is a leap year 29 Days in February.";
    }
    else
    cout << year << " is not a leap year is not a leap year 28 Days.";}
    cout << endl;
     return 0;
}