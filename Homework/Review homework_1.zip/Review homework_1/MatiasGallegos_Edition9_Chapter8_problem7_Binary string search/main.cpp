/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: MatiasGallegos
 *
 * Created on June 27, 2021, 5:20 PM
 */

#include <cstdlib>
#include <iostream>
#include <string> 
using namespace std;
void selectionSort(string[], int);
void swap(string &, string &);
void displayArray(string[], int, string);
int binarySearch(string[], int, string);

int main(int argc, char** argv) {
    const int NUM_NAMES = 20;
    // All the names
    string names[NUM_NAMES] = {"Collins, Bill", "Smith, Bart", "Allen, Jim",
                               "Griffin, Jim", "Stamey, Marty", "Rose, Geri", 
                               "Taylor, Terri", "Johnson, Jill", 
                               "Allison, Jeff", "Looney, Joe", "Wolfe, Bill", 
                               "James, Jean", "Weaver, Jim", "Pore, Bob", 
                               "Rutherford, Greg", "Javens, Renee", 
                               "Harrison, Rose", "Setzer, Cathy",
                               "Pike, Gordon", "Holland, Beth" };
    //Sorted names
    selectionSort(names, NUM_NAMES);
    displayArray(names, NUM_NAMES, "SORTED: \n");
    // pick a name
    string user_name;
    cout << "Pick a name: ";
    getline(cin, user_name);

    int position = binarySearch(names, NUM_NAMES, user_name);

    if (position != -1)
       cout << names[position] << " was found." << endl;
    else
        cout << user_name << " was NOT found." << endl;
    

    return 0; 
}

void selectionSort(string array[], int ARRAY_SIZE)
{
    int min_index;
    string min_value;

    for (int start_index = 0; start_index < (ARRAY_SIZE - 1); start_index++)
    {
        min_index = start_index;
        min_value = array[start_index];

        for (int index = start_index + 1; index < ARRAY_SIZE; index++)
        {
            if (array[index] < min_value)
            {
                min_value = array[index];
                min_index = index;
            }
        }
        swap(array[min_index], array[start_index]);
    }
}

void swap(string &a, string &b)
{
    string temp = a;
    a = b;
    b = temp;
}

void displayArray(string array[], int ARRAY_SIZE, string prompt)
{
    cout << prompt << endl;
    for (int i = 0; i < ARRAY_SIZE; i++)
        cout << array[i] << endl;
    cout << endl;
}

int binarySearch(string array[], int array_size, string user_name)
{
    int first = 0,
        last = array_size - 1,  // 19
        middle,
        position = -1;
    bool found = false;

    while (!found && first <= last)
    {
        // is 2
        middle = (first + last) / 2; 

        if (array[middle] == user_name)
        {
            position = middle;
            found = true;
        }
        else if (array[middle] > user_name) 
            last = middle - 1; 
        else                                
            first = middle + 1; 
        
    }
    return position;
}
