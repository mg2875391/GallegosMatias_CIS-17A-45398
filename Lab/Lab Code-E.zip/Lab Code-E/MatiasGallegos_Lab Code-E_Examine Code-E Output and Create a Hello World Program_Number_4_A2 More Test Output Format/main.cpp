/* 
 * File:
 * Author:
 * Date:
 * Purpose:
 * Version:
 */

//System Libraries - Post Here
#include <iostream>
#include <iomanip>
using namespace std;

int main(int argc, char** argv) {
    float a;
    cin>>a;
    cout<<noshowpoint<<setprecision(0)<<setw(9)<<a<<showpoint<<fixed<<setprecision(1)<<setw(10)<<a<<setprecision(2)<<setw(10)<<a<<endl;
    float b;
    cin>>b;
     cout<<noshowpoint<<setprecision(0)<<setw(9)<<b<<showpoint<<fixed<<setprecision(1)<<setw(10)<<b<<setprecision(2)<<setw(10)<<b<<endl;
    float c;
    cin>>c;
     cout<<noshowpoint<<setprecision(0)<<setw(9)<<c<<showpoint<<fixed<<setprecision(1)<<setw(10)<<c<<setprecision(2)<<setw(10)<<c<<endl;
    float d;
    cin>>d;
     cout<<noshowpoint<<setprecision(0)<<setw(9)<<d<<showpoint<<fixed<<setprecision(1)<<setw(10)<<d<<setprecision(2)<<setw(10)<<d;
    
    return 0;
}