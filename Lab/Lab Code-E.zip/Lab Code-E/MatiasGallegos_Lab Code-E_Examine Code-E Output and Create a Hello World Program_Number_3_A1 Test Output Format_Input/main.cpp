/* 
 * File:
 * Author:
 * Date:
 * Purpose:
 * Version:
 */

//System Libraries - Post Here
#include <iostream>
#include <iomanip>
using namespace std;

int main(int argc, char** argv) {
     int number;
     float number2;
    cin>>number>>number2;
    cout<<(number)<<endl;
    cout<<(number2)<<endl;
    cout<<"Hello World     "<<endl;
            cout<<"\tTab it!"<<endl;
    cout<<"Compare . . . to space   ";
    return 0;
}