/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: matij
 *
 * Created on July 15, 2021, 7:42 PM
 */

#include <cstdlib>
#include <bits/stdc++.h>

using namespace std;
struct Customer
{
    string name; // Customers Name

    string address; // Customers address

    int account; // account number

    float balance; // Balance at the beginning of the month

    float cTotal[100]; // Total of all checks written this month

    float dTotal[100]; //Total of all deposits credited to the account this month
};

bool Check_Five_Digit(int n)
{
    int c=0;
    while(n>0)
{
        
        c++;

        n=n/10;
    }
    if(c==5)
    return true;
    else
        return false;
}

int main(int argc, char *argv[])
{ 
    
    Customer* cus = new Customer;
    cout<<"Bank Account"<<endl;
    string name,address;
    int checks, deposits,acc;
    float bal,sum=0,diff=0,total=0,x;
    cout << "Enter the name for the customer: ";
    getline(cin,name);
    cus->name=name;
    cout << "Enter the address : ";
    getline(cin, address);
    cus->address=address;
    cout << "Enter the five digit account number: ";
    cin >>acc;
    while(!Check_Five_Digit(acc))
    {
        cout << "Invalid account number. Please enter a 5 digit account number: ";
        cin >> acc;
        }
    cus->account=acc;
    cout << "Enter the account balance: ";
    cin >> bal;
    sum = sum + bal;
    cout <<"How many checks did you write this month?: ";
    cin >> checks;
    
for(int i = 0; i < checks; i++)
{
    cout << "Enter the amount for the current check: ";
    cin >> x;
    cus->cTotal[i]=x;
    diff += x;
    }
    cout << "Total amount from checks: " << diff << endl;
    cout << "How many deposits would you like to enter for this month?: ";
    cin >> deposits;

    for(int i = 0; i < deposits; i++)
    {
    cout << "Enter the amount for the current deposit: ";
    cin >>x;
    cus->dTotal[i]=x;
    sum += x;
    }
    cout <<endl;
    cout << "Deposits: " << sum << endl;
    total = sum - diff;
    cout << "Account balance at the end of the month is: " << total << endl;
    if(total < 0)
{
    cout<<"The account has been overdrawn. An additional $50 dollar fee has been accessed. The new balance is "<<(total - 50)<<endl;
}
    cout <<cus->name << " at " << cus->address << " with the account "
    "number of " << cus->account << " has a balance of $" << total
    << endl;
    return 0;
}