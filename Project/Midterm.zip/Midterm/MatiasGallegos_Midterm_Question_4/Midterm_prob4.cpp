/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: matij
 *
 * Created on July 16, 2021, 3:00 PM
 */
#include <cstdlib>
#include<iostream>
using namespace std;

void encrypt(int a)
{
    int first,second,third,fourth; //for storing respective digit of a
    fourth=a%10; //storing fourth digit of a
    a/=10; //dividing a by 10
    third=a%10; //storing third digit of a
    a/=10; //dividing a by 10
    second=a%10; //storing second digit of a
    a/=10; //dividing a by 10
    first=a; //storing first digit of a

    if(first==8||first==9||second==8||second==9||third==8||third==9||fourth==8||fourth==9)
    { //if any digit is 8 or 9 print error message
        cout<<"8 or 9 cannot be in the number\n\n";
        return;
    }
    //encrypting the numbers
    first=(first+5)%8;
    second=(second+5)%8;
    third=(third+5)%8;
    fourth=(fourth+5)%8;
    int number=1000*third+100*fourth+10*first+second;
    cout<<"Encrypted number is "<<number<<endl; //displaying the number
}
void decrypt(int a)
{
    int first,second,third,fourth; //for storing respective digit of a
    fourth=a%10;//storing fourth digit of a
    a/=10; //dividing a by 10
    third=a%10; //storing third digit a
    a/=10; //dividing 
    second=a%10; //storing second digit a
    a/=10; //dividing
    first=a; //storing first digit a

    if(first==8||first==9||second==8||second==9||third==8||third==9||fourth==8||fourth==9)
    { //if any digit is 8 or 9 print error
        cout<<"8 or 9 cannot be in the number\n\n";\
    return;
}
    first=(first-5+8)%8;
    second=(second+3)%8;
    third=(third+3)%8;
    fourth=(fourth+3)%8;
    
    int number=1000*third+100*fourth+10*first+second;
        cout<<"Decrypted number is "<<number<<endl; //displaying decrypted number
}
int main(int argc, char *argv[])
{
    int number;
    cout<<"Enter the number to be encrypted: ";
    cin>>number; //entering number to be encrypted
    encrypt(number); //encrypting number
    cout<<"Enter the number to be decrypted: ";
    cin>>number;
    decrypt(number);
    return 0;
}
