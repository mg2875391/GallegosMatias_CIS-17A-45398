/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: matij
 *
 * Created on July 16, 2021, 6:38 PM
 */

#include <cstdlib>
#include<iostream>

using namespace std;
//struct declarations
struct Prime
{
     unsigned int prime;
     unsigned int power;
};
struct Primes
{
    Prime *prime;
    unsigned int nPrimes;
};
Primes *factor(int n)
{
    int k=2;
    int m[10000]={0};//initially to store prime factors
    while(1<n)
{
        if(n%k==0)

{
            m[k]++;//finding prime factor
            n=n/k;   
}
else
    k++;
}
    //finding prime factors
    int i=0;
    k=0;
    while(i<10000)
{
        if(m[i]!=0)k++;
        i++;
}
    Primes *p = new Primes;
    p->nPrimes=k;
    p->prime = new Prime[k];//creating prime array
    i=0;
    k=0;
    while(i<10000)
{
        if(m[i]!=0)
{
            p->prime[k].prime = i;

            p->prime[k].power = m[i];
            k++;
}
        i++;
}
return p;//returning primes
}

//method to print primes
void prnt(Primes *p)
{
    int n = p->nPrimes;
    int k=0;
    while(k<n)
{
        cout<<p->prime[k].prime<<"^"<<p->prime[k].power<<"*";
        k++;
        if(k==n-1)break;
}
    cout<<p->prime[k].prime<<"^"<<p->prime[k].power<<endl;
}

int main(int argc, char *argv[])
{
    Primes *p = factor(120);
    cout<<"Primes 120 = ";
    // Prime *n = new Prime[10];
    prnt(p);
    return 0;
}
