/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: matij
 *
 * Created on July 15, 2021, 8:05 PM
 */

#include <cstdlib>
#include <iostream>
using namespace std;
struct emp
{
   string c,a,name;
   double time,rate,gross;  
  
};
//function to calculate gross pay
double gross_pay(double time,double rate)
{
   if(time<=40)
   {
   return time*rate;  
   }
   else if(time<40)
   {
       return (20*rate)+(2*(time-40)*rate);   //straight time for first 20 hrs + double time for excess of 40 hrs
   }
   else
   {
       return (20*rate)+(2*(10)*rate)+(3*(time-40)*rate);//straight time for first 20 hrs + double time for excess of 40 hrs
   }
  
}
int main(int argc, char *argv[])
{
   string c,a;
   int n;
   cout<<"Enter number of employee's:";
   cin>>n;
   //declaring array of structure
   struct emp e[n];
   //reading employee details
   getline(cin,c);
   int i=0;
   while(i<n)
   {
       cout<<"enter employee name:";
       getline(cin,e[i].name);
       double t=0;
       //reading company name and address
   cout<<"Enter company name:";
   getline(cin,e[i].c);
   cout<<"Enter company address:";
   getline(cin,e[i].a);
       do
       {
           cout<<"enter hours worked";
           cin>>t;
           //if t is positive then loop stops
       }
       while(t<0);///runs up to a positive number is entered
       e[i].time=t;
       do
       {
           cout<<"enter rate of pay:";
           cin>>t;
           //if t is positive then loop stops
       }
       while(t<0);///runs up to a positive number
       e[i].rate=t;
       e[i].gross = gross_pay(e[i].time,e[i].rate);//gross pay
       getline(cin,c);
   i++;  
   }
   for(int i=0;i<n;i++)
   {
           cout<<"Company :"<<e[i].c<<endl;
           cout<<"Address :"<<e[i].a<<endl;
           cout<<"Name :"<<e[i].name<<endl;
           cout<<"Amount :"<<e[i].gross<<endl;
           cout<<"Signature Line: "<<endl;
   }
   return 0;
}